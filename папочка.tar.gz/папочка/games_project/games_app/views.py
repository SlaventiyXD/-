from re import search

from django.shortcuts import render
from .models import Game
from django.db.models import Q
# Create your views here.
def game1(request):
    games = Game.objects.all()

    search_game = request.GET.get('search', '')#Поиск по названию и жанру
    if search_game:
        games = games.filter(
            Q(name__icontains = search_game) |
            Q(ganr__icontains = search_game)
        )


    return render(request, 'games.html', {
        'games': games,
        'search_game': search_game
    })


def game2(request):
    games = Game.objects.all()

    date_filter = request.GET.get('date', '')#Фильтрация по дате
    if date_filter:
        games = games.filter(date__year__gte=int(date_filter))

    return render(request, 'games_filter.html', {
        'games': games,
        'date_filter': date_filter
    })